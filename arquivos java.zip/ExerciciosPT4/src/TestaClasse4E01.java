import java.util.Scanner;

public class TestaClasse4E01 {

	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		Aluno a = new Aluno();
		Funcionario f = new Funcionario();
		Pessoa p = new Pessoa();
		Professor pr = new Professor();
	
				
		p.setNome("Carlos");
		a.setNome("joão");
		pr.setNome("Mario");
		f.setNome("Anna");
		

	        System.out.print("Qual a quantidade: ");

	        int num1 = entrada.nextInt();

	        
		 System.out.println("Digite abaixo : ");
	        System.out.println("\n\n[1] Professor ");
	        System.out.println("[2] Aluno");
	        System.out.println("[3] Pessoa");
	        System.out.println("[4] Funcionario ");
	        System.out.println("                      >> Digite uma opcao: ");

          
	        int cla = entrada.nextInt();
	        double quantidade = 0.00;
	        switch(cla)
	        {
	            case 1:
                    
	                double professor = quantidade * 0.10;
	                System.out.println("valor da impressão: "+professor);

	                break;
		
	               case 2:

	            	   double aluno = quantidade *0.07;
		                System.out.println("valor da impressão: "+aluno);

	            	   break;
	               case 3:

	            	   double funcionario = quantidade *0.10;
		                System.out.println("valor da impressão: "+funcionario);

	            	   break;
	               case 4:

	            	   double pessoa = quantidade *0.10;
		                System.out.println("valor da impressão: "+pessoa);
		                
		             break;

		                default:
                           System.out.print("Operacao invalida!!");
	                }

}
	
}
	
