package ExercicioP4E02;

public class TestaClasse {

	public static void main(String[] args) {
				Funcionario a = new Funcionario();
				a.setNome("Antonio da Silva");
				a.setRg("333.444.533-4");
				a.setSalarioMensal(5300.0);
				
				System.out.println("Pagamento...: R$ "+a.pagamento());
				
				Chefe b = new Chefe();
				b.setNome("Barbara");
				b.setRg("45632897");
				b.setSalarioMensal(12789.0);
				b.setAdicionalChefia(2899.0);
				b.setContas(1587.0);
				b.setGastosExtras(7999.0);
				
				System.out.println("Pagamento...: R$ "+b.pagamentoExtra());
		

	}

}
