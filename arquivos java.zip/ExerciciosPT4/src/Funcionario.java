import java.sql.Date;

public class Funcionario extends Pessoa {
	protected double salario;
	protected Date dataAdmissao;
	protected String cargo;
	
	public Funcionario() {
		super();
	}

	public Funcionario(double salario, Date dataAdmissao, String cargo) {
		super();
		this.salario = salario;
		this.dataAdmissao = dataAdmissao;
		this.cargo = cargo;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public Date getDataAdmissao() {
		return dataAdmissao;
	}

	public void setDataAdmissao(Date dataAdmissao) {
		this.dataAdmissao = dataAdmissao;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	
	
	
}
