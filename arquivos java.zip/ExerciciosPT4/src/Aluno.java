import java.sql.Date;

public class Aluno extends Pessoa{

	protected String matricula;
	

	public Aluno() {
		super();
	}

	public Aluno(String matricula) {
		super();
		this.matricula = matricula;
	}

	public String getMatricula() {
		return matricula;
	}

	public String setMatricula (String matricula) {
		return this.matricula = matricula;
	}
	 

	public  double tirarCopias(int quantidades) {
		 return quantidades * 0.07;
		
	} 
	
}
