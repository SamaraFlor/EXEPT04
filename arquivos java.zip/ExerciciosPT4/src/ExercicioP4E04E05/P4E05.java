package ExercicioP4E04E05;

import java.util.Scanner;

public class P4E05 {

	public static void main(String[] args) {
	   Scanner entrada = new Scanner (System.in);
	   
	   boolean erro = true;
	   int numInteiro=0;
	   do {
		   try {
			   System.out.print("Informe a sua idade....: ");
			   numInteiro = entrada.nextInt();
			   erro = false;
		   }
		   catch(Exception e) {
			   System.out.println("Este não é numerico");
			   erro = true;
			   entrada.nextLine();
		   }
	   } while (erro);
	   
	   System.out.print("Você digitou: "+numInteiro);
   }
}


