package ExercicioP4E04E05;

public class P4E04 {
	public static void main(String [] args) {
		System.out.println("Antes de chamar metodoA()");
		metodoA();
		System.out.println("Depois de chamar metodoA()");
	}
	public static void metodoA() {
		try {
			System.out.println("Antes de chamar metodoB()");
			metodoB();
			System.out.println("Depois de chamar metodoB()");
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
	public static void metodoB() {
		System.out.println("Antes de chamar metodoC()");
		metodoC();
		System.out.println("Depois de chamar metodoC()");
	}
	public static void metodoC() {
		System.out.println("Antes de chamar metodoD()");
		metodoD();
		System.out.println("Depois de chamar metodoD()");
	}
	public static void metodoD() {
		System.out.println("Antes da divis�o no metodoD()");
		int n = 10/0;
		System.out.println("Depois da divis�o no metodoD()");
	}
	
}
